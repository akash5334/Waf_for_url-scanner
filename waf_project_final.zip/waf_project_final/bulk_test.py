import requests

URLS_FILE="test_urls.txt"
WAF_ENDPOINT="http://127.0.0.1:5000/"

def test_urls():
    with open(URLS_FILE) as f:
        urls=[u.strip() for u in f if u.strip()]
    for u in urls:
        r=requests.post(WAF_ENDPOINT, data={'url':u})
        print(f"Tested: {u} | Status Code: {r.status_code}")

if __name__=="__main__":
    test_urls()
