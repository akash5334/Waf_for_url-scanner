import os
import re
import datetime
import sqlite3
import logging
from urllib.parse import urlparse
import random, string
import base64
import requests
from flask import Flask, request, render_template, jsonify, g, redirect

# Load config
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "YOUR_GOOGLE_SAFE_BROWSING_API_KEY")
VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "YOUR_VIRUSTOTAL_API_KEY")
MAX_REDIRECTS = int(os.getenv("MAX_REDIRECTS", 5))

app = Flask(__name__)
DB_FILE = "waf.db"

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

# ------------------- DB HELPERS -------------------
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_FILE)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.execute("CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY, timestamp TEXT, url TEXT, status TEXT, detail TEXT, chain TEXT)")
    db.commit()

with app.app_context():
    init_db()

# ------------------- HELPERS -------------------
def ensure_scheme(url):
    if not re.match(r'^[a-zA-Z]+://', url):
        url = 'http://' + url
    return url

def is_suspicious(url):
    patterns = [r"free[-_.]gift", r"malware", r"login[-_.]stealer", r"\.exe", r"\.zip"]
    for pat in patterns:
        if re.search(pat, url, re.IGNORECASE):
            return True
    return False

def log_url(url, status, detail="", chain=""):
    try:
        db = get_db()
        db.execute("INSERT INTO logs (timestamp,url,status,detail,chain) VALUES (?,?,?,?,?)",
                   (datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), url, status, detail, chain))
        db.commit()
    except Exception as e:
        log.error(f"DB error: {e}")

def check_google_safebrowsing(url):
    if not GOOGLE_API_KEY or GOOGLE_API_KEY.startswith("YOUR_"):
        return False, "GSB_NOT_CONFIGURED"
    try:
        resp = requests.post(
            f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={GOOGLE_API_KEY}",
            json={
                "client": {"clientId": "wafapp", "clientVersion": "1.0"},
                "threatInfo": {
                    "threatTypes": ["MALWARE","SOCIAL_ENGINEERING"],
                    "platformTypes": ["ANY_PLATFORM"],
                    "threatEntryTypes": ["URL"],
                    "threatEntries": [{"url": url}]
                }
            }, timeout=8
        ).json()
        return bool(resp.get("matches")), "GSB_MATCH" if resp.get("matches") else "GSB_CLEAR"
    except:
        return False, "GSB_ERROR"

def check_virustotal(url):
    if not VIRUSTOTAL_API_KEY or VIRUSTOTAL_API_KEY.startswith("YOUR_"):
        return False, "VT_NOT_CONFIGURED"
    vt_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    try:
        r = requests.get(f"https://www.virustotal.com/api/v3/urls/{vt_id}", headers={"x-apikey": VIRUSTOTAL_API_KEY}, timeout=8)
        if r.status_code == 404:
            return False, "VT_UNKNOWN"
        data = r.json()
        stats = data.get("data",{}).get("attributes",{}).get("last_analysis_stats",{})
        bad = stats.get("malicious",0)>0 or stats.get("suspicious",0)>0
        return bad, "VT_MALICIOUS" if bad else "VT_CLEAR"
    except:
        return False, "VT_ERROR"

def evaluate_single(url):
    if is_suspicious(url):
        return True, "RULE_MATCH"
    gsb, gsb_detail = check_google_safebrowsing(url)
    if gsb:
        return True, gsb_detail
    vt, vt_detail = check_virustotal(url)
    if vt:
        return True, vt_detail
    return False, "CLEAN"

def evaluate_with_redirects(url):
    url = ensure_scheme(url)
    try:
        resp = requests.get(url, allow_redirects=True, timeout=8)
        chain = [r.url for r in resp.history] + [resp.url]
    except:
        chain = [url]

    if len(chain) > MAX_REDIRECTS:
        chain = chain[:MAX_REDIRECTS]

    for idx, link in enumerate(chain):
        bad, reason = evaluate_single(link)
        if bad:
            return True, f"CHAIN_MATCH(step={idx},reason={reason})", chain
    return False, "CLEAN", chain

# ------------------- TEST MODE -------------------
def generate_suspicious_url():
    base_domains = ["apple.com","paypal.com","amazon.com","facebook.com","netflix.com"]
    fake_tlds = ["-secure-login.com","-verify-account.net",".ru",".cn",".tk"]
    domain = random.choice(base_domains).replace("a","@").replace("o","0")
    suffix = random.choice(fake_tlds)
    path = "/login?" + "".join(random.choices(string.ascii_letters+string.digits,k=8))
    return f"http://{domain}{suffix}{path}"

# ------------------- ROUTES -------------------
@app.route("/", methods=["GET","POST"])
def index():
    result=""
    detail=""
    url=""
    chain=""
    if request.method=="POST":
        url = request.form.get("url","")
        bad, detail, chain_list = evaluate_with_redirects(url)
        chain = " -> ".join(chain_list)
        if bad:
            result="❌ Malicious / Suspicious URL Detected!"
            log_url(url,"Blocked",detail,chain)
        else:
            result="✅ Safe URL"
            log_url(url,"Safe",detail,chain)
    return render_template("index.html", result=result, detail=detail, submitted_url=url, chain=chain)

@app.route("/test-url")
def test_url():
    fake_url = generate_suspicious_url()
    return f"<h3>Generated Suspicious URL:</h3><p>{fake_url}</p><a href='/'>Back</a>"

@app.route("/redirect-test")
def redirect_test():
    return redirect(generate_suspicious_url(), code=302)

@app.route("/admin/logs")
def view_logs():
    rows = get_db().execute("SELECT * FROM logs ORDER BY id DESC LIMIT 50").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/admin/reset", methods=["POST"])
def reset_logs():
    get_db().execute("DELETE FROM logs")
    get_db().commit()
    return jsonify({"status":"ok","message":"Logs cleared."})

@app.route("/healthz")
def healthz():
    return jsonify({"status":"healthy"})

if __name__=="__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
