# WAF Project (Final Version)
Features:
- URL scanning with regex + Google Safe Browsing + VirusTotal
- Redirect chain analysis
- Test mode (generate fake phishing URLs)
- Admin panel with logs
- Docker support

## Local Run
```
pip install -r requirements.txt
python app.py
```

## Docker
```
docker-compose up --build
```

Open http://127.0.0.1:5000
